﻿'use strict';
(function () {
    // Create Edit controller
    function VersionsController($route, $scope, $routeParams, $filter, appState, treeService, navigationService, hkVersionsResource, userService, notificationsService, localizationService, dialogService, eventsService) {
        // Set a property on the scope equal to the current route id
        $scope.id = $routeParams.id;

        $scope.reloadRoute = function () {
            $route.reload();
        };

        localizationService.localize("FALM_VersionsManager.FilterByNodeId").then(function (value) {
            $scope.FilterByNodeId = value;
        });
        localizationService.localize("FALM_VersionsManager.FilterByNodeName").then(function (value) {
            $scope.FilterByNodeName = value;
        });
        localizationService.localize("FALM_VersionsManager.FilterByDateFrom").then(function (value) {
            $scope.FilterByDateFrom = value;
        });
        localizationService.localize("FALM_VersionsManager.FilterByDateTo").then(function (value) {
            $scope.FilterByDateTo = value;
        });

        // GET - VIEW VERSIONS
        $scope.showLoader = false;

        // Get all versions via hkVersionsResource
        hkVersionsResource.getPublishedNodes().then(function (response) {
            $scope.showLoader = true;
            $scope.versions = response.data;
            $scope.showLoader = false;   // hide loader
        });

        // Table search
        $scope.search = '';

        // Table sort
        $scope.sortType = '';
        $scope.reverse = false;
        $scope.sort = function (keyname) {
            $scope.sortKey = keyname;           //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse;   //if true make it false and vice versa
        };

        // Table pagination
        $scope.currentPage = 1;
        $scope.pageSize = 10;
        $scope.totalPages = 1;

        // POST - DELETE VIEWED LOGS
        $scope.versionsSuccessNotification = {
            'type': 'success',
            'sticky': false
        };
        localizationService.localize("FALM_VersionsManager.Cleanup.DeleteLogsSuccessHeadline").then(function (value) {
            $scope.versionsSuccessNotification.headline = value;
        });
        localizationService.localize("FALM_VersionsManager.Cleanup.DeleteLogsSuccessMessage").then(function (value) {
            $scope.versionsSuccessNotification.message = value;
        });

        $scope.versionsErrorNotification = {
            "type": "error",
            "headline": "",
            "sticky": false
        };
        localizationService.localize("FALM_VersionsManager.Cleanup.DeleteLogsErrorHeadline").then(function (value) {
            $scope.versionsErrorNotification.headline = value;
        });
        localizationService.localize("FALM_VersionsManager.Cleanup.DeleteLogsErrorMessage").then(function (value) {
            $scope.versionsErrorNotification.message = value;
        });

        localizationService.localize("FALM_VersionsManager.Cleanup.ConfirmationMessage").then(function (value) {
            $scope.confirmDeleteActionMessage = value;
        });

        // Delete filtered Logs via hkLogsResource
        $scope.deleteVersionsByCount = function () {
            if (confirm($scope.confirmDeleteActionMessage)) {
                $scope.showLoader = true;
                hkVersionsResource.deleteVersionsByCount(0).then(function (response) {
                    if (response.data != null) {
                        notificationsService.add($scope.versionsSuccessNotification);
                        $route.reload();
                    }
                    else {
                        notificationsService.add($scope.versionsErrorNotification);
                        $scope.showDeletePanel = false;
                    }
                });
                $scope.showLoader = false;
            }
        };

        // Open details modal
        $scope.openDetailsModal = function (versionItem) {
            var dialog = dialogService.open({
                template: '/App_Plugins/FALM/backoffice/housekeeping/view/versions-manager-modal-details.html',
                dialogData: {
                    currentPublishedVersionItem: versionItem
                },
                show: true,
                width: 800
            });
        };

        // Open cleanup by count modal
        $scope.openCleanupByCountModal = function () {
            var cbcDialog = dialogService.open({
                template: '/App_Plugins/FALM/backoffice/housekeeping/view/versions-manager-modal-cleanupbycount.html',
                show: true,
                width: 800
            });
        };

        // TREE NODE HIGHLIGHT
        var activeNode = appState.getTreeState("selectedNode");
        if (activeNode) {
            var activeNodePath = treeService.getPath(activeNode).join();
            navigationService.syncTree({ tree: $routeParams.tree, path: activeNodePath, forceReload: false, activate: true });
        } else {
            navigationService.syncTree({ tree: $routeParams.tree, path: ["-1", "versions", $routeParams.id], forceReload: false, activate: true });
        }
    }

    // Register the controller
    angular.module("umbraco").controller("FALMHousekeepingVersionsController", VersionsController);
})();